# Reddit comment pack — 25 игр для «Сходится!»

В комплекте находится sidecar-пак для режима `game`: 25 игр, 150 переведённых
комментариев Reddit и пять наборов по пять раундов.

Главное свойство модели: **основные карточки игр не переписываются**. Комментарии
живут в `content_pack_entries.prompt_payload`, а каждая запись пакета ссылается на
существующий `content_items.id`.

## Состав архива

- `reddit-games-comments-25-v1.json` — основной пакет.
- `reddit-games-comments-25.schema.json` — JSON Schema.
- `reddit-games-comments-25-validation.json` — отчёт проверки.
- `reddit-games-comments-25-index.md` — индекс игр и пяти наборов.
- `import-reddit-comment-pack.ts` — импорт и разрешение игр против активной ревизии БД.
- `pack-prompt-runtime-helper.ts` — чтение комментариев из `prompt_payload`.
- `game-service-pack-integration.md` — точечные изменения API и клиента.
- `CHECKSUMS.sha256` — контрольные суммы файлов.

## Модель совместимости

У каждой игры есть `answerRef`:

```json
{
  "mode": "game",
  "titleRu": "Starfield",
  "titleOriginal": "Starfield",
  "year": 2023,
  "steamAppIds": [1716740],
  "aliases": ["Старфилд", "Star Field"],
  "resolutionOrder": [
    "steamAppId",
    "normalizedTitleAndYear",
    "normalizedTitle",
    "alias",
    "fallback"
  ]
}
```

Импортёр ищет карточку в активной ревизии в таком порядке:

1. Steam App ID.
2. Нормализованное название и год.
3. Название или алиас при совместимом годе.
4. Скрытая fallback-карточка, только когда передан `--materialize-missing`.

Проверка года намеренно строгая: ремейк не должен случайно привязаться к
оригинальной игре с тем же названием.

## Установка файлов

Рекомендуемые пути внутри репозитория:

```text
data/promo/reddit-games-comments-25-v1.json
data/promo/reddit-games-comments-25.schema.json
scripts/content/import-reddit-comment-pack.ts
apps/api/src/modules/packs/prompt-runtime.ts
docs/game-service-pack-integration.md
```

## Первый аудит каталога

Запустите импорт без дополнительных флагов:

```bash
pnpm tsx scripts/content/import-reddit-comment-pack.ts \
  --source=data/promo/reddit-games-comments-25-v1.json \
  --report=var/reddit-games-comments-25-import-report.json
```

Если хотя бы одной карточки нет, импортёр:

- создаст подробный отчёт;
- перечислит название, год, Steam App ID и алиасы;
- завершится с кодом `2`;
- **не изменит БД**.

После этого недостающие игры можно добавить существующими игровыми пайплайнами
проекта, собрать и активировать новую ревизию, затем повторить команду.

В репозитории уже есть подходящие инструменты:

```text
scripts/games/import-steam.mjs
scripts/games/import-thegamesdb-incremental.mjs
scripts/games/backfill-missing-cards.mjs
```

## Немедленный закрытый предпросмотр

Для проверки интерфейса до обогащения каталога:

```bash
pnpm tsx scripts/content/import-reddit-comment-pack.ts \
  --source=data/promo/reddit-games-comments-25-v1.json \
  --report=var/reddit-games-comments-25-import-report.json \
  --materialize-missing
```

Так создаются только недостающие fallback-карточки:

```text
allowedInGame = false
contentStatus = reddit_comment_pack
```

Они не попадут в обычную ежедневную игру. После добавления полноценных карточек
повторный импорт перепривяжет позиции пакета к каноническим объектам.

## Draft и публикация

Без флага пакет сохраняется как `draft`.

Для перевода в `published`:

```bash
pnpm tsx scripts/content/import-reddit-comment-pack.ts \
  --source=data/promo/reddit-games-comments-25-v1.json \
  --report=var/reddit-games-comments-25-import-report.json \
  --publish
```

Публиковать следует после подключения generic pack runtime. Сам импорт данных не
заменяет изменения из `game-service-pack-integration.md`.

## Как хранятся комментарии

Исходный JSON содержит:

- английский оригинал;
- русский перевод;
- экранную версию после минимальной редакторской обработки;
- источник;
- силу подсказки;
- момент открытия;
- сведения о скрытых названиях.

В БД импортёр переносит только данные, необходимые игровому runtime:

- `displayTextRu` в виде `progressiveHints`;
- уровень открытия;
- идентификатор источника;
- безопасную ссылку на источник;
- служебные флаги.

Английские оригиналы не помещаются в player-facing `prompt_payload`, поэтому API
не сможет случайно выдать ответ из исходной цитаты.

## Порядок открытия

Во всех 25 раундах используется единая схема:

```text
0 ошибок — два стартовых комментария
1 ошибка  — третий комментарий
2 ошибки — четвёртый комментарий
3 ошибки — пятый комментарий
5 ошибок — спасательный комментарий
```

Рекомендуемый лимит — 6 попыток. В текущем движке встречается жёстко заданное
значение 10, поэтому сервер и клиент нужно переключить на поле `maxAttempts`.
Отдельная миграция для этого не требуется: существующий диапазон БД уже допускает
значения до 10.

## Пять заходов

Пак разбит на пять фиксированных наборов по пять игр. Первый набор предназначен
для трафика из промо-поста; остальные открываются после завершения предыдущего.

Это позволяет:

- всем посетителям поста сравнивать одинаковый первый результат;
- выдавать законченный итог после пяти игр;
- сохранить ещё четыре повтора без дубликатов;
- хранить прогресс на существующих позициях `content_pack_entries`.

Награда за первый заход и бейдж за `5/5` описаны как продуктовая спецификация в
`pack.experience`. Отдельного типа ваучера в текущей экономике пока нет, поэтому
автоматическая выдача награды требует дополнительной серверной операции.

## Проверка источников

Пак имеет статус:

```text
publicationStatus = research_only
rightsStatus = unverified
```

42 источника ведут непосредственно на ветки Reddit. Четыре записи требуют ручной
замены или удаления перед публичной сборкой:

- две вторичные цитаты для Hogwarts Legacy;
- два контекста из профилей Reddit для Silent Hill 2 Remake.

Они перечислены в `reddit-games-comments-25-validation.json`.

## Что импортёр принципиально не делает

- не изменяет payload существующих карточек;
- не включает fallback-карточки в обычный пул;
- не угадывает ремейк по одному совпавшему названию при другом годе;
- не публикует пакет без явного `--publish`;
- не продолжает импорт при неразрешённых играх;
- не раскрывает английские оригиналы в игровой сессии.
